//
//  ViewController.m
//  M_Archive
//
//  Created by 彼岸熊 on 16/12/3.
//  Copyright © 2016年 彼岸熊. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self save];
    [self delete];
//    [self read];
}

- (void)save {
    
    NSString *urlStr = @"http://iappfree.candou.com:8080/free/applications/recommend?longitude=116.344539&latitude=40.034346";
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain",@"text/json",@"application/json",@"text/javascript",@"text/html",nil];
    [manager GET:urlStr parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {

        NSString *homtPath = NSHomeDirectory();
        NSLog(@"%@",homtPath);
        
        NSMutableData *mutableData = [[NSMutableData alloc] init];
        NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:mutableData];
        [archiver encodeObject:responseObject forKey:@"save"];
        [archiver finishEncoding];
        //写文件
        [mutableData writeToFile:[NSString stringWithFormat:@"%@/Documents/save",homtPath] atomically:YES];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}

- (void)delete {

    NSString *homtPath = NSHomeDirectory();
    NSLog(@"%@",homtPath);
    NSString *filePath = [homtPath stringByAppendingPathComponent:@"/Documents/save"];
    NSFileManager *manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]) {
        
        NSLog(@"文件已存在");
    }
    else {
    
        NSLog(@"文件不存在了");
    }
    [manager removeItemAtPath:filePath error:nil];
}

- (void)read {
    
    NSString *homtPath = NSHomeDirectory();
    NSLog(@"%@",homtPath);
    NSData *data = [NSData dataWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/save",homtPath]];
    //解归档
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];

    NSDictionary *dic = [unarchiver decodeObjectForKey:@"save"];
    NSLog(@"%@",dic);
}




@end
